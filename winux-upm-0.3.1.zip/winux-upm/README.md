# Winux UPM 0.3.1

UPM 0.3.1 connects the CLI to the engine API.

Commands:
- `upm detect <file>`
- `upm inspect <file>`
- `upm validate <file>`
- `upm engines`

`inspect` and `validate` select an engine from the detected package format.
Mutating operations remain safe stubs and perform no installation, removal, or execution.
