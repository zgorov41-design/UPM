import contextlib
import io
import sys
import tempfile
import unittest

from upm import cli


class CLITests(unittest.TestCase):
    def run_main(self, args):
        old = sys.argv
        out = io.StringIO()
        try:
            sys.argv = ["upm"] + list(args)
            with contextlib.redirect_stdout(out):
                code = cli.main()
        finally:
            sys.argv = old
        return code, out.getvalue()

    def test_inspect_uses_engine(self):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b"!<arch>\n")
            name = f.name
        code, output = self.run_main(["inspect", name, "--json"])
        self.assertEqual(code, 0)
        self.assertIn('"format": "deb"', output)

    def test_validate_unknown_returns_nonzero(self):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b"hello")
            name = f.name
        code, output = self.run_main(["validate", name, "--json"])
        self.assertEqual(code, 1)
        self.assertIn('"format": "unknown"', output)

    def test_inspect_help_contains_command(self):
        old = sys.argv
        try:
            sys.argv = ["upm", "--help"]
            with self.assertRaises(SystemExit) as cm:
                cli.main()
            self.assertEqual(cm.exception.code, 0)
        finally:
            sys.argv = old


if __name__ == "__main__":
    unittest.main()
