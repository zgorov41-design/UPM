from __future__ import annotations
import argparse
import json

from .detector import detect_package
from .core.registry import available_engines, get_engine
from . import engines  # noqa: F401 - registers built-in engines


def _print_result(result: dict, as_json: bool) -> None:
    if as_json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"{result['format']}: {result['status']} - {result['description']}")


def _engine_for_path(path: str):
    detected = detect_package(path)
    if detected.format not in available_engines():
        return None, detected
    return get_engine(detected.format), detected


def main() -> int:
    parser = argparse.ArgumentParser(prog="upm")
    sub = parser.add_subparsers(dest="command", required=True)

    p_detect = sub.add_parser("detect", help="detect package format")
    p_detect.add_argument("path")
    p_detect.add_argument("--json", action="store_true")

    p_inspect = sub.add_parser("inspect", help="inspect a package using its engine")
    p_inspect.add_argument("path")
    p_inspect.add_argument("--json", action="store_true")

    p_validate = sub.add_parser("validate", help="validate a package using its engine")
    p_validate.add_argument("path")
    p_validate.add_argument("--json", action="store_true")

    sub.add_parser("engines", help="list available engines")

    args = parser.parse_args()

    if args.command == "detect":
        _print_result(detect_package(args.path).to_dict(), args.json)
        return 0

    if args.command == "engines":
        print("\n".join(available_engines()))
        return 0

    if args.command in {"inspect", "validate"}:
        engine, detected = _engine_for_path(args.path)
        if engine is None:
            result = detected.to_dict()
            result["details"] = dict(result.get("details") or {})
            result["details"]["engine"] = None
            _print_result(result, args.json)
            return 1

        if args.command == "inspect":
            result = engine.inspect(args.path)
        else:
            result = engine.validate(args.path)
        _print_result(result, args.json)
        return 0 if result.get("status") not in {"invalid"} else 1

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
