from __future__ import annotations
from typing import Type
from .engine import PackageEngine

_REGISTRY: dict[str, Type[PackageEngine]] = {}


def register_engine(engine_cls: Type[PackageEngine]) -> Type[PackageEngine]:
    _REGISTRY[engine_cls.format] = engine_cls
    return engine_cls


def get_engine(format_name: str) -> PackageEngine:
    try:
        return _REGISTRY[format_name]()
    except KeyError as exc:
        raise KeyError(f"Unknown package engine: {format_name}") from exc


def available_engines() -> list[str]:
    return sorted(_REGISTRY)
